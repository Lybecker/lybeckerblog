﻿using System.Net.Security;
using System.ServiceModel;

namespace Shared
{
    [ServiceContract(Namespace = "www.lybecker.com/blog/wcfriddle")]
    public interface IMyService
    {
        [OperationContract(ProtectionLevel = ProtectionLevel.EncryptAndSign)]
        string LooongRunningMethod(string name);
    }
}