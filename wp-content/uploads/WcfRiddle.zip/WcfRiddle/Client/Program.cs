﻿using System;
using System.Linq;
using System.ServiceModel;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ready? Press [ENTER]...");
            Console.ReadLine();

            var names = new[] { "Anders", "Bende", "Bo", "Egon", "Jakob", "Jesper", "Jonas", "Martin", "Ove", "Rasmus", "Thomas E", "Thomas" };

            var result = from name in names.AsParallel().WithDegreeOfParallelism(12)
                         select CallService(name);

            result.ForAll(Console.WriteLine);

            Console.WriteLine("Done processing...");
            Console.ReadLine();
        }

        static string CallService(string name)
        {
            Console.WriteLine("{0} starting", name);

            var factory = new ChannelFactory<Shared.IMyService>(
                new WSHttpBinding(),
                new EndpointAddress("http://localhost:8080/MyService"));

            var proxy = factory.CreateChannel();

            var result = proxy.LooongRunningMethod(name);

            Console.WriteLine("{0} ending", name);

            return result;
        }
    }
}