﻿using System;
using System.ServiceModel;
using Shared;
using System.Linq;

namespace Service
{
    public class MyService : IMyService
    {
        public string LooongRunningMethod(string name)
        {
            Console.WriteLine("{0} entered.", name);

            // Simulate work by random sleeping :-)
            var rnd = new Random(name.Select(Convert.ToInt32).Sum() + Environment.TickCount);
            var sleepSeconds = rnd.Next(0, 100);
            System.Threading.Thread.Sleep(sleepSeconds * 1000);

            var message = string.Format("{0} slept for {1} seconds in session {2}.", name, sleepSeconds, OperationContext.Current.SessionId);
            Console.WriteLine(message);

            return message;
        }
    }
}