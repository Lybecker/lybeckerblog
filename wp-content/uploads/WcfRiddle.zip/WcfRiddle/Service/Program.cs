﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace Service
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var host = new ServiceHost(
                typeof(MyService),
                new Uri("http://localhost:8080/MyService")))
            {
                host.AddServiceEndpoint(
                    typeof(Shared.IMyService),
                    new WSHttpBinding(), "");

                host.Description.Behaviors.Add(
                    new ServiceMetadataBehavior() {HttpGetEnabled = true});

                host.Open();

                Console.WriteLine("Service running.");
                Console.WriteLine("Press [ENTER] to terminate service...");
                Console.ReadLine();
            }
        }
    }
}
