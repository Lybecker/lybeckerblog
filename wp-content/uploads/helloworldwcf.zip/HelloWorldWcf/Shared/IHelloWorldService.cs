using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

[ServiceContract]
public interface IHelloWorldService
{
    [OperationContract]
    string HelloWorld();
}