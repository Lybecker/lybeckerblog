using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

public class HelloWorldService : IHelloWorldService
{
    public string HelloWorld()
    {
        return "Hello World";
    }
}