﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Lucene.Net.Analysis;
using Lucene.Net.Analysis.Snowball;
using Lucene.Net.Analysis.Standard;
using Lucene.Net.Analysis.Tokenattributes;

namespace Com.Lybecker.AnalyzerViewer
{
    class Program
    {
        static void Main(string[] args)
        {
            Action<Analyzer, String> displayAction = DisplayTokensWithFullDetails;

            Lucene.Net.Util.Version version = Lucene.Net.Util.Version.LUCENE_29;

            var text = "The quick brown fox jumped over the lazy dogs";

            Console.WriteLine("Original string: {0}", text);
            Console.WriteLine();

            Analyzer analyzer = new KeywordAnalyzer();
            displayAction(analyzer, text);
            analyzer = new WhitespaceAnalyzer();
            displayAction(analyzer, text);
            analyzer = new SimpleAnalyzer();
            displayAction(analyzer, text);
            analyzer = new StopAnalyzer(version);
            displayAction(analyzer, text);
            analyzer = new StandardAnalyzer(version);
            displayAction(analyzer, text);

            //new PerFieldAnalyzerWrapper()
        }

        public static void DisplayTokens(Analyzer analyzer, String text)
        {
            Console.WriteLine("Analyzing with {0}", analyzer.GetType().FullName);
            DisplayTokens(analyzer.TokenStream("contents", new StringReader(text)));
            Console.WriteLine();
            Console.WriteLine();
        }

        public static void DisplayTokens(TokenStream tokenStream)
        {
            var term = (TermAttribute)tokenStream.AddAttribute(typeof(TermAttribute));
            while (tokenStream.IncrementToken())
            {
                Console.Write("[" + term.Term() + "] ");
            }
        }

        public static void DisplayTokensWithFullDetails(Analyzer analyzer, String text)
        {
            Console.WriteLine("Analyzing with {0}", analyzer.GetType().FullName);

            TokenStream stream = analyzer.TokenStream("contents", new StringReader(text));

            var term = (TermAttribute)stream.AddAttribute(typeof(TermAttribute));
            var posIncr = (PositionIncrementAttribute)stream.AddAttribute(typeof(PositionIncrementAttribute));
            var offset = (OffsetAttribute)stream.AddAttribute(typeof(OffsetAttribute));
            var type = (TypeAttribute)stream.AddAttribute(typeof(TypeAttribute));

            int position = 0;
            while (stream.IncrementToken())
            {
                int increment = posIncr.GetPositionIncrement();
                if (increment > 0)
                {
                    position = position + increment;
                    Console.Write(position + ": ");
                }

                Console.WriteLine("[{0}:{1}->{2}:{3}] ", term.Term(), offset.StartOffset(), offset.EndOffset(), type.Type());
            }
            Console.WriteLine();
        }
    }
}
