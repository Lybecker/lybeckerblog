using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

[ServiceContract(Namespace = "www.lybecker.com/blog/HelloWorldService")]
public interface IHelloWorldService
{
    [OperationContract]
    string HelloWorld();
}