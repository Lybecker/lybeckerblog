﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace WcfServer
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Diagnostics.Trace.CorrelationManager.ActivityId = new Guid(new string('1', 32));

            using (var host = new ServiceHost(typeof(Calculator), 
                new Uri("net.tcp://localhost:8080/Calculator")))
            {
                host.Open();

                Console.WriteLine("Host started. Press ENTER to terminate.");
                Console.ReadLine();
                host.Close();
            }
        }
    }
}
