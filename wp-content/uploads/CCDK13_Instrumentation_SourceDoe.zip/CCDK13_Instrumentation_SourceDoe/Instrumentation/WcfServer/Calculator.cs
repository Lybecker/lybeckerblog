﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WcfContract;
using System.Diagnostics;

namespace WcfServer
{
    public class Calculator : ICalculator
    {
        TraceSource traceSource = new TraceSource("serverTraceSource");

        public int Add(int a, int b)
        {
            traceSource.TraceInformation("Adding {0} + {1}", a, b);
            return a + b;
        }

        public int Multiply(int a, int b)
        {
            traceSource.TraceInformation("Multiplying {0} + {1}", a, b);

            return a * b;
        }
    }
}
