﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using WcfContract;
using System.Diagnostics;

namespace WcfClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var traceSource = new TraceSource("clientTraceSource");

            System.Diagnostics.Trace.CorrelationManager.ActivityId = Guid.NewGuid();

            var factory = new ChannelFactory<ICalculator>(new NetTcpBinding());

            var proxy = factory.CreateChannel(
                new EndpointAddress("net.tcp://localhost:8080/Calculator"));

            ((IClientChannel)proxy).Open();
            traceSource.TraceInformation("Sending request...");
            var result = proxy.Add(40, 2);
            ((IClientChannel)proxy).Close();

            factory.Close();
            Console.WriteLine("Result: {0}", result);
            Console.ReadLine();

            traceSource.TraceEvent(TraceEventType.Critical, 42, "You terminated!");
        }
    }
}