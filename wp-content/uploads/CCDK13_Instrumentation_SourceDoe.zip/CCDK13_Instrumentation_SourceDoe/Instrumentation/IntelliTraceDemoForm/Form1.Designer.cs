﻿namespace IntermittentProblemCS
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNumLabel = new System.Windows.Forms.Label();
            this.secondNumLabel = new System.Windows.Forms.Label();
            this.thirdNumLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.firstNumText = new System.Windows.Forms.TextBox();
            this.secondNumText = new System.Windows.Forms.TextBox();
            this.thirdNumText = new System.Windows.Forms.TextBox();
            this.totalText = new System.Windows.Forms.TextBox();
            this.PopulateData = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNumLabel
            // 
            this.firstNumLabel.AutoSize = true;
            this.firstNumLabel.Location = new System.Drawing.Point(12, 16);
            this.firstNumLabel.Name = "firstNumLabel";
            this.firstNumLabel.Size = new System.Drawing.Size(51, 13);
            this.firstNumLabel.TabIndex = 0;
            this.firstNumLabel.Text = "First Num";
            // 
            // secondNumLabel
            // 
            this.secondNumLabel.AutoSize = true;
            this.secondNumLabel.Location = new System.Drawing.Point(12, 53);
            this.secondNumLabel.Name = "secondNumLabel";
            this.secondNumLabel.Size = new System.Drawing.Size(69, 13);
            this.secondNumLabel.TabIndex = 1;
            this.secondNumLabel.Text = "Second Num";
            // 
            // thirdNumLabel
            // 
            this.thirdNumLabel.AutoSize = true;
            this.thirdNumLabel.Location = new System.Drawing.Point(12, 84);
            this.thirdNumLabel.Name = "thirdNumLabel";
            this.thirdNumLabel.Size = new System.Drawing.Size(56, 13);
            this.thirdNumLabel.TabIndex = 2;
            this.thirdNumLabel.Text = "Third Num";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(12, 115);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(31, 13);
            this.totalLabel.TabIndex = 3;
            this.totalLabel.Text = "Total";
            // 
            // firstNumText
            // 
            this.firstNumText.Location = new System.Drawing.Point(91, 16);
            this.firstNumText.Name = "firstNumText";
            this.firstNumText.Size = new System.Drawing.Size(100, 20);
            this.firstNumText.TabIndex = 4;
            // 
            // secondNumText
            // 
            this.secondNumText.Location = new System.Drawing.Point(91, 53);
            this.secondNumText.Name = "secondNumText";
            this.secondNumText.Size = new System.Drawing.Size(100, 20);
            this.secondNumText.TabIndex = 5;
            // 
            // thirdNumText
            // 
            this.thirdNumText.Location = new System.Drawing.Point(91, 84);
            this.thirdNumText.Name = "thirdNumText";
            this.thirdNumText.Size = new System.Drawing.Size(100, 20);
            this.thirdNumText.TabIndex = 6;
            // 
            // totalText
            // 
            this.totalText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalText.Location = new System.Drawing.Point(91, 115);
            this.totalText.Name = "totalText";
            this.totalText.Size = new System.Drawing.Size(100, 20);
            this.totalText.TabIndex = 7;
            // 
            // PopulateData
            // 
            this.PopulateData.Location = new System.Drawing.Point(76, 153);
            this.PopulateData.Name = "PopulateData";
            this.PopulateData.Size = new System.Drawing.Size(127, 23);
            this.PopulateData.TabIndex = 8;
            this.PopulateData.Text = "Populate Data";
            this.PopulateData.UseVisualStyleBackColor = true;
            this.PopulateData.Click += new System.EventHandler(this.PopulateData_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(280, 206);
            this.Controls.Add(this.PopulateData);
            this.Controls.Add(this.totalText);
            this.Controls.Add(this.thirdNumText);
            this.Controls.Add(this.secondNumText);
            this.Controls.Add(this.firstNumText);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.thirdNumLabel);
            this.Controls.Add(this.secondNumLabel);
            this.Controls.Add(this.firstNumLabel);
            this.Name = "MainForm";
            this.Text = "Main Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNumLabel;
        private System.Windows.Forms.Label secondNumLabel;
        private System.Windows.Forms.Label thirdNumLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.TextBox firstNumText;
        private System.Windows.Forms.TextBox secondNumText;
        private System.Windows.Forms.TextBox thirdNumText;
        private System.Windows.Forms.TextBox totalText;
        private System.Windows.Forms.Button PopulateData;
    }
}

