﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntermittentProblemCS
{
    public partial class MainForm : Form
    {
        private NumberData myNumData;

        public MainForm()
        {
            InitializeComponent();

            
        }

        private void PopulateData_Click(object sender, EventArgs e)
        {
            // get our numberdata object
            myNumData = new NumberData();

            // populate our controls
            firstNumText.Text = myNumData.firstNum.ToString();
            secondNumText.Text = myNumData.secondNum.ToString();
            thirdNumText.Text = myNumData.thirdNum.ToString();
            totalText.Text = myNumData.total.ToString();
        }
    }
}