﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntermittentProblemCS
{
    class NumberData
    {
        private double numberOne;
        private double numberTwo;
        private double numberThree;

        public double firstNum {get { return Math.Round(numberOne); }}

        public double secondNum { get { return Math.Round(numberTwo); } }

        public double thirdNum { get { return Math.Round(numberThree); } }

        public double total { get { 
            return Math.Round(numberOne + numberTwo + numberThree); 
        } }

        public NumberData()
        {
            // create a random number generator to simulate 
            // database activity or similar
            Random myRand = new Random();

            // populate our numbers with data
            this.numberOne = myRand.NextDouble() * 10;
            this.numberTwo = myRand.NextDouble() * 10;
            this.numberThree = myRand.NextDouble() * 10;
        }
    }
}
