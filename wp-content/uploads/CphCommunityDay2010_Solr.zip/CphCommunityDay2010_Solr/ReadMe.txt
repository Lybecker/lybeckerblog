By Anders Lybecker (http://www.lybecker.com/blog/)

Configuring and running Solr
Prerequisites: an installeted Java Virtual Machine
1. Download Solr and upzip
2. Drop the Solr_Conf/Schema.xml and Solr_Conf/solrconfig.xml into the <Solr Home>\example\solr\conf folder
3. Open a command prompt and type java -jar start.jar
4. Open a browser with http://localhost:8983/solr/admin to verify that Solr is running

Adding content to the Solr index
1. Open the SolrPlayground/SolrPlayground.sln in Visual Studio 2010
2. Build and run the project (F5)
3. Wait until the "Done adding to Solr"

Searching
1. Open the SolrPlayground/SolrNetClient/Default.htm in a browser
2. Search for e.g. The Matrix
