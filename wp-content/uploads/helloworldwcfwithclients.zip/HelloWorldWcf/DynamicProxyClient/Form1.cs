using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;

namespace DynamicProxyClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        IHelloWorldService proxy = null;

        private void InitializeProxy()
        {
            ChannelFactory<IHelloWorldService> factory = new ChannelFactory<IHelloWorldService>("myEndPoint");

            proxy = factory.CreateChannel();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (proxy == null)
                InitializeProxy();

            MessageBox.Show(proxy.HelloWorld());
        }
    }
}