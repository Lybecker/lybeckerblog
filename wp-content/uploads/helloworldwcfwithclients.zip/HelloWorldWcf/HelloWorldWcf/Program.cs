using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

class Program
{
    static void Main(string[] args)
    {
        using (ServiceHost host = 
            new ServiceHost(typeof(HelloWorldService)))
        {
            host.Open();

            Console.WriteLine("The HelloWorldService is running.");
            Console.WriteLine("Press [ENTER] to terminate...");
            Console.ReadLine();
        }
    }
}