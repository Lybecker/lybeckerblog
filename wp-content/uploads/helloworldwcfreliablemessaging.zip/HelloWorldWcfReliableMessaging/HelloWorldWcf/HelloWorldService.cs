using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
public class HelloWorldService : IHelloWorldService
{
    public string HelloWorld()
    {
        Console.WriteLine("Invoked by client with session ID {0}", 
            OperationContext.Current.SessionId);

        return "Hello World";
    }
}