﻿function RemoveSvnFolders([string]$path) 
{
    Write-Host "Removing .svn folders in path $path recursive"
	
	Get-ChildItem $path -Include ".svn" -Force -Recurse | 
		Where {$_.psIsContainer -eq $true} | 
		Foreach ($_) 
		{ 
			Remove-Item $_.Fullname -Force -Recurse -WhatIf 
		}
}

# Uncomment to remove .svn folders
#RemoveSvnFolders("c:\svn\My Solution")

# List properties of files and folders in current directory
#Get-ChildItem | format-list -property * 